setwd("/Users/forgetmenotblue/Downloads")
Delivery_Times<-read.table("/Users/forgetmenotblue/Downloads/Exercise - Lab 05.txt", header = TRUE, sep = ",")
# Rename column for easy use
colnames(Delivery_Times) <- c("X1")


# 2. Draw histogram with nine class intervals (20–70, right open)
hist(Delivery_Times$X1,
     breaks = seq(20, 70, length.out = 10),   # 9 classes → 10 break points
     right = FALSE,                          # right-open intervals
     col = "purple",
     main = "Histogram of Delivery Times (9 Classes, 20–70)",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency")


# 3. Comment on the shape:
# The histogram is approximately symmetric with a slight right skew
# Mean ≈ 43.8, Median ≈ 42.5


# 4.Histogram object without plotting
h <- hist(Delivery_Times$X1,
          breaks = seq(20, 70, length.out = 10),
          right = FALSE, plot = FALSE)

# Cumulative frequencies
cum_freq <- cumsum(h$counts)

# Plot Ogive
plot(h$breaks[-1], cum_freq, type = "o", pch = 16, col = "hotpink",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency")